// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros2_hi6_msgs:msg/Num.idl
// generated code does not contain a copyright notice

#ifndef ROS2_HI6_MSGS__MSG__NUM_H_
#define ROS2_HI6_MSGS__MSG__NUM_H_

#include "ros2_hi6_msgs/msg/detail/num__struct.h"
#include "ros2_hi6_msgs/msg/detail/num__functions.h"
#include "ros2_hi6_msgs/msg/detail/num__type_support.h"

#endif  // ROS2_HI6_MSGS__MSG__NUM_H_
