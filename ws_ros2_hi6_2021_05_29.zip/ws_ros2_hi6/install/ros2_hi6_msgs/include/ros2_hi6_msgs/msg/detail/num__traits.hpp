// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from ros2_hi6_msgs:msg/Num.idl
// generated code does not contain a copyright notice

#ifndef ROS2_HI6_MSGS__MSG__DETAIL__NUM__TRAITS_HPP_
#define ROS2_HI6_MSGS__MSG__DETAIL__NUM__TRAITS_HPP_

#include "ros2_hi6_msgs/msg/detail/num__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<ros2_hi6_msgs::msg::Num>()
{
  return "ros2_hi6_msgs::msg::Num";
}

template<>
inline const char * name<ros2_hi6_msgs::msg::Num>()
{
  return "ros2_hi6_msgs/msg/Num";
}

template<>
struct has_fixed_size<ros2_hi6_msgs::msg::Num>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<ros2_hi6_msgs::msg::Num>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<ros2_hi6_msgs::msg::Num>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ROS2_HI6_MSGS__MSG__DETAIL__NUM__TRAITS_HPP_
