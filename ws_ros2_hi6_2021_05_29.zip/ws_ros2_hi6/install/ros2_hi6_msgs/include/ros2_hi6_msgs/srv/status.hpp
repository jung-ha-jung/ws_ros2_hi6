// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROS2_HI6_MSGS__SRV__STATUS_HPP_
#define ROS2_HI6_MSGS__SRV__STATUS_HPP_

#include "ros2_hi6_msgs/srv/detail/status__struct.hpp"
#include "ros2_hi6_msgs/srv/detail/status__builder.hpp"
#include "ros2_hi6_msgs/srv/detail/status__traits.hpp"

#endif  // ROS2_HI6_MSGS__SRV__STATUS_HPP_
