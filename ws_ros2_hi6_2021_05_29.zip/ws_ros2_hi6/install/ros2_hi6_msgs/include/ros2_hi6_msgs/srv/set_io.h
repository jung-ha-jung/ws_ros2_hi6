// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros2_hi6_msgs:srv/SetIO.idl
// generated code does not contain a copyright notice

#ifndef ROS2_HI6_MSGS__SRV__SET_IO_H_
#define ROS2_HI6_MSGS__SRV__SET_IO_H_

#include "ros2_hi6_msgs/srv/detail/set_io__struct.h"
#include "ros2_hi6_msgs/srv/detail/set_io__functions.h"
#include "ros2_hi6_msgs/srv/detail/set_io__type_support.h"

#endif  // ROS2_HI6_MSGS__SRV__SET_IO_H_
