// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from ros2_hi6_msgs:srv/Trigger.idl
// generated code does not contain a copyright notice

#ifndef ROS2_HI6_MSGS__SRV__DETAIL__TRIGGER__TRAITS_HPP_
#define ROS2_HI6_MSGS__SRV__DETAIL__TRIGGER__TRAITS_HPP_

#include "ros2_hi6_msgs/srv/detail/trigger__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<ros2_hi6_msgs::srv::Trigger_Request>()
{
  return "ros2_hi6_msgs::srv::Trigger_Request";
}

template<>
inline const char * name<ros2_hi6_msgs::srv::Trigger_Request>()
{
  return "ros2_hi6_msgs/srv/Trigger_Request";
}

template<>
struct has_fixed_size<ros2_hi6_msgs::srv::Trigger_Request>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<ros2_hi6_msgs::srv::Trigger_Request>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<ros2_hi6_msgs::srv::Trigger_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<ros2_hi6_msgs::srv::Trigger_Response>()
{
  return "ros2_hi6_msgs::srv::Trigger_Response";
}

template<>
inline const char * name<ros2_hi6_msgs::srv::Trigger_Response>()
{
  return "ros2_hi6_msgs/srv/Trigger_Response";
}

template<>
struct has_fixed_size<ros2_hi6_msgs::srv::Trigger_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<ros2_hi6_msgs::srv::Trigger_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<ros2_hi6_msgs::srv::Trigger_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<ros2_hi6_msgs::srv::Trigger>()
{
  return "ros2_hi6_msgs::srv::Trigger";
}

template<>
inline const char * name<ros2_hi6_msgs::srv::Trigger>()
{
  return "ros2_hi6_msgs/srv/Trigger";
}

template<>
struct has_fixed_size<ros2_hi6_msgs::srv::Trigger>
  : std::integral_constant<
    bool,
    has_fixed_size<ros2_hi6_msgs::srv::Trigger_Request>::value &&
    has_fixed_size<ros2_hi6_msgs::srv::Trigger_Response>::value
  >
{
};

template<>
struct has_bounded_size<ros2_hi6_msgs::srv::Trigger>
  : std::integral_constant<
    bool,
    has_bounded_size<ros2_hi6_msgs::srv::Trigger_Request>::value &&
    has_bounded_size<ros2_hi6_msgs::srv::Trigger_Response>::value
  >
{
};

template<>
struct is_service<ros2_hi6_msgs::srv::Trigger>
  : std::true_type
{
};

template<>
struct is_service_request<ros2_hi6_msgs::srv::Trigger_Request>
  : std::true_type
{
};

template<>
struct is_service_response<ros2_hi6_msgs::srv::Trigger_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // ROS2_HI6_MSGS__SRV__DETAIL__TRIGGER__TRAITS_HPP_
