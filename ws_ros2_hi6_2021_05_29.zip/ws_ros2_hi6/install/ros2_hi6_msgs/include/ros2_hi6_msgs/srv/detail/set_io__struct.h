// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ros2_hi6_msgs:srv/SetIO.idl
// generated code does not contain a copyright notice

#ifndef ROS2_HI6_MSGS__SRV__DETAIL__SET_IO__STRUCT_H_
#define ROS2_HI6_MSGS__SRV__DETAIL__SET_IO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'type'
#include "rosidl_runtime_c/string.h"

// Struct defined in srv/SetIO in the package ros2_hi6_msgs.
typedef struct ros2_hi6_msgs__srv__SetIO_Request
{
  rosidl_runtime_c__String type;
  int32_t blk_no;
  int32_t sig_no;
  int32_t val;
} ros2_hi6_msgs__srv__SetIO_Request;

// Struct for a sequence of ros2_hi6_msgs__srv__SetIO_Request.
typedef struct ros2_hi6_msgs__srv__SetIO_Request__Sequence
{
  ros2_hi6_msgs__srv__SetIO_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ros2_hi6_msgs__srv__SetIO_Request__Sequence;


// Constants defined in the message

// Struct defined in srv/SetIO in the package ros2_hi6_msgs.
typedef struct ros2_hi6_msgs__srv__SetIO_Response
{
  bool success;
} ros2_hi6_msgs__srv__SetIO_Response;

// Struct for a sequence of ros2_hi6_msgs__srv__SetIO_Response.
typedef struct ros2_hi6_msgs__srv__SetIO_Response__Sequence
{
  ros2_hi6_msgs__srv__SetIO_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ros2_hi6_msgs__srv__SetIO_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROS2_HI6_MSGS__SRV__DETAIL__SET_IO__STRUCT_H_
