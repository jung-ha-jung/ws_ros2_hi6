// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ros2_hi6_msgs:srv/Status.idl
// generated code does not contain a copyright notice

#ifndef ROS2_HI6_MSGS__SRV__DETAIL__STATUS__BUILDER_HPP_
#define ROS2_HI6_MSGS__SRV__DETAIL__STATUS__BUILDER_HPP_

#include "ros2_hi6_msgs/srv/detail/status__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace ros2_hi6_msgs
{

namespace srv
{

namespace builder
{

class Init_Status_Request_data2
{
public:
  explicit Init_Status_Request_data2(::ros2_hi6_msgs::srv::Status_Request & msg)
  : msg_(msg)
  {}
  ::ros2_hi6_msgs::srv::Status_Request data2(::ros2_hi6_msgs::srv::Status_Request::_data2_type arg)
  {
    msg_.data2 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ros2_hi6_msgs::srv::Status_Request msg_;
};

class Init_Status_Request_data1
{
public:
  Init_Status_Request_data1()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Status_Request_data2 data1(::ros2_hi6_msgs::srv::Status_Request::_data1_type arg)
  {
    msg_.data1 = std::move(arg);
    return Init_Status_Request_data2(msg_);
  }

private:
  ::ros2_hi6_msgs::srv::Status_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::ros2_hi6_msgs::srv::Status_Request>()
{
  return ros2_hi6_msgs::srv::builder::Init_Status_Request_data1();
}

}  // namespace ros2_hi6_msgs


namespace ros2_hi6_msgs
{

namespace srv
{

namespace builder
{

class Init_Status_Response_result
{
public:
  Init_Status_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::ros2_hi6_msgs::srv::Status_Response result(::ros2_hi6_msgs::srv::Status_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ros2_hi6_msgs::srv::Status_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::ros2_hi6_msgs::srv::Status_Response>()
{
  return ros2_hi6_msgs::srv::builder::Init_Status_Response_result();
}

}  // namespace ros2_hi6_msgs

#endif  // ROS2_HI6_MSGS__SRV__DETAIL__STATUS__BUILDER_HPP_
