// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from ros2_hi6_msgs:srv/GetIO.idl
// generated code does not contain a copyright notice

#ifndef ROS2_HI6_MSGS__SRV__DETAIL__GET_IO__STRUCT_HPP_
#define ROS2_HI6_MSGS__SRV__DETAIL__GET_IO__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__ros2_hi6_msgs__srv__GetIO_Request __attribute__((deprecated))
#else
# define DEPRECATED__ros2_hi6_msgs__srv__GetIO_Request __declspec(deprecated)
#endif

namespace ros2_hi6_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct GetIO_Request_
{
  using Type = GetIO_Request_<ContainerAllocator>;

  explicit GetIO_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->type = "";
      this->blk_no = 0l;
      this->sig_no = 0l;
    }
  }

  explicit GetIO_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : type(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->type = "";
      this->blk_no = 0l;
      this->sig_no = 0l;
    }
  }

  // field types and members
  using _type_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _type_type type;
  using _blk_no_type =
    int32_t;
  _blk_no_type blk_no;
  using _sig_no_type =
    int32_t;
  _sig_no_type sig_no;

  // setters for named parameter idiom
  Type & set__type(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->type = _arg;
    return *this;
  }
  Type & set__blk_no(
    const int32_t & _arg)
  {
    this->blk_no = _arg;
    return *this;
  }
  Type & set__sig_no(
    const int32_t & _arg)
  {
    this->sig_no = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    ros2_hi6_msgs::srv::GetIO_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const ros2_hi6_msgs::srv::GetIO_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<ros2_hi6_msgs::srv::GetIO_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<ros2_hi6_msgs::srv::GetIO_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      ros2_hi6_msgs::srv::GetIO_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<ros2_hi6_msgs::srv::GetIO_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      ros2_hi6_msgs::srv::GetIO_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<ros2_hi6_msgs::srv::GetIO_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<ros2_hi6_msgs::srv::GetIO_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<ros2_hi6_msgs::srv::GetIO_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__ros2_hi6_msgs__srv__GetIO_Request
    std::shared_ptr<ros2_hi6_msgs::srv::GetIO_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__ros2_hi6_msgs__srv__GetIO_Request
    std::shared_ptr<ros2_hi6_msgs::srv::GetIO_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GetIO_Request_ & other) const
  {
    if (this->type != other.type) {
      return false;
    }
    if (this->blk_no != other.blk_no) {
      return false;
    }
    if (this->sig_no != other.sig_no) {
      return false;
    }
    return true;
  }
  bool operator!=(const GetIO_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GetIO_Request_

// alias to use template instance with default allocator
using GetIO_Request =
  ros2_hi6_msgs::srv::GetIO_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace ros2_hi6_msgs


#ifndef _WIN32
# define DEPRECATED__ros2_hi6_msgs__srv__GetIO_Response __attribute__((deprecated))
#else
# define DEPRECATED__ros2_hi6_msgs__srv__GetIO_Response __declspec(deprecated)
#endif

namespace ros2_hi6_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct GetIO_Response_
{
  using Type = GetIO_Response_<ContainerAllocator>;

  explicit GetIO_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->val = 0l;
      this->success = false;
    }
  }

  explicit GetIO_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->val = 0l;
      this->success = false;
    }
  }

  // field types and members
  using _val_type =
    int32_t;
  _val_type val;
  using _success_type =
    bool;
  _success_type success;

  // setters for named parameter idiom
  Type & set__val(
    const int32_t & _arg)
  {
    this->val = _arg;
    return *this;
  }
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    ros2_hi6_msgs::srv::GetIO_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const ros2_hi6_msgs::srv::GetIO_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<ros2_hi6_msgs::srv::GetIO_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<ros2_hi6_msgs::srv::GetIO_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      ros2_hi6_msgs::srv::GetIO_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<ros2_hi6_msgs::srv::GetIO_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      ros2_hi6_msgs::srv::GetIO_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<ros2_hi6_msgs::srv::GetIO_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<ros2_hi6_msgs::srv::GetIO_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<ros2_hi6_msgs::srv::GetIO_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__ros2_hi6_msgs__srv__GetIO_Response
    std::shared_ptr<ros2_hi6_msgs::srv::GetIO_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__ros2_hi6_msgs__srv__GetIO_Response
    std::shared_ptr<ros2_hi6_msgs::srv::GetIO_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GetIO_Response_ & other) const
  {
    if (this->val != other.val) {
      return false;
    }
    if (this->success != other.success) {
      return false;
    }
    return true;
  }
  bool operator!=(const GetIO_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GetIO_Response_

// alias to use template instance with default allocator
using GetIO_Response =
  ros2_hi6_msgs::srv::GetIO_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace ros2_hi6_msgs

namespace ros2_hi6_msgs
{

namespace srv
{

struct GetIO
{
  using Request = ros2_hi6_msgs::srv::GetIO_Request;
  using Response = ros2_hi6_msgs::srv::GetIO_Response;
};

}  // namespace srv

}  // namespace ros2_hi6_msgs

#endif  // ROS2_HI6_MSGS__SRV__DETAIL__GET_IO__STRUCT_HPP_
