// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ros2_hi6_msgs:srv/GetIO.idl
// generated code does not contain a copyright notice

#ifndef ROS2_HI6_MSGS__SRV__DETAIL__GET_IO__BUILDER_HPP_
#define ROS2_HI6_MSGS__SRV__DETAIL__GET_IO__BUILDER_HPP_

#include "ros2_hi6_msgs/srv/detail/get_io__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace ros2_hi6_msgs
{

namespace srv
{

namespace builder
{

class Init_GetIO_Request_sig_no
{
public:
  explicit Init_GetIO_Request_sig_no(::ros2_hi6_msgs::srv::GetIO_Request & msg)
  : msg_(msg)
  {}
  ::ros2_hi6_msgs::srv::GetIO_Request sig_no(::ros2_hi6_msgs::srv::GetIO_Request::_sig_no_type arg)
  {
    msg_.sig_no = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ros2_hi6_msgs::srv::GetIO_Request msg_;
};

class Init_GetIO_Request_blk_no
{
public:
  explicit Init_GetIO_Request_blk_no(::ros2_hi6_msgs::srv::GetIO_Request & msg)
  : msg_(msg)
  {}
  Init_GetIO_Request_sig_no blk_no(::ros2_hi6_msgs::srv::GetIO_Request::_blk_no_type arg)
  {
    msg_.blk_no = std::move(arg);
    return Init_GetIO_Request_sig_no(msg_);
  }

private:
  ::ros2_hi6_msgs::srv::GetIO_Request msg_;
};

class Init_GetIO_Request_type
{
public:
  Init_GetIO_Request_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GetIO_Request_blk_no type(::ros2_hi6_msgs::srv::GetIO_Request::_type_type arg)
  {
    msg_.type = std::move(arg);
    return Init_GetIO_Request_blk_no(msg_);
  }

private:
  ::ros2_hi6_msgs::srv::GetIO_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::ros2_hi6_msgs::srv::GetIO_Request>()
{
  return ros2_hi6_msgs::srv::builder::Init_GetIO_Request_type();
}

}  // namespace ros2_hi6_msgs


namespace ros2_hi6_msgs
{

namespace srv
{

namespace builder
{

class Init_GetIO_Response_success
{
public:
  explicit Init_GetIO_Response_success(::ros2_hi6_msgs::srv::GetIO_Response & msg)
  : msg_(msg)
  {}
  ::ros2_hi6_msgs::srv::GetIO_Response success(::ros2_hi6_msgs::srv::GetIO_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ros2_hi6_msgs::srv::GetIO_Response msg_;
};

class Init_GetIO_Response_val
{
public:
  Init_GetIO_Response_val()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GetIO_Response_success val(::ros2_hi6_msgs::srv::GetIO_Response::_val_type arg)
  {
    msg_.val = std::move(arg);
    return Init_GetIO_Response_success(msg_);
  }

private:
  ::ros2_hi6_msgs::srv::GetIO_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::ros2_hi6_msgs::srv::GetIO_Response>()
{
  return ros2_hi6_msgs::srv::builder::Init_GetIO_Response_val();
}

}  // namespace ros2_hi6_msgs

#endif  // ROS2_HI6_MSGS__SRV__DETAIL__GET_IO__BUILDER_HPP_
