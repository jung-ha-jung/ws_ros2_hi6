// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from ros2_hi6_msgs:srv/GetIO.idl
// generated code does not contain a copyright notice

#ifndef ROS2_HI6_MSGS__SRV__DETAIL__GET_IO__TRAITS_HPP_
#define ROS2_HI6_MSGS__SRV__DETAIL__GET_IO__TRAITS_HPP_

#include "ros2_hi6_msgs/srv/detail/get_io__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<ros2_hi6_msgs::srv::GetIO_Request>()
{
  return "ros2_hi6_msgs::srv::GetIO_Request";
}

template<>
inline const char * name<ros2_hi6_msgs::srv::GetIO_Request>()
{
  return "ros2_hi6_msgs/srv/GetIO_Request";
}

template<>
struct has_fixed_size<ros2_hi6_msgs::srv::GetIO_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<ros2_hi6_msgs::srv::GetIO_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<ros2_hi6_msgs::srv::GetIO_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<ros2_hi6_msgs::srv::GetIO_Response>()
{
  return "ros2_hi6_msgs::srv::GetIO_Response";
}

template<>
inline const char * name<ros2_hi6_msgs::srv::GetIO_Response>()
{
  return "ros2_hi6_msgs/srv/GetIO_Response";
}

template<>
struct has_fixed_size<ros2_hi6_msgs::srv::GetIO_Response>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<ros2_hi6_msgs::srv::GetIO_Response>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<ros2_hi6_msgs::srv::GetIO_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<ros2_hi6_msgs::srv::GetIO>()
{
  return "ros2_hi6_msgs::srv::GetIO";
}

template<>
inline const char * name<ros2_hi6_msgs::srv::GetIO>()
{
  return "ros2_hi6_msgs/srv/GetIO";
}

template<>
struct has_fixed_size<ros2_hi6_msgs::srv::GetIO>
  : std::integral_constant<
    bool,
    has_fixed_size<ros2_hi6_msgs::srv::GetIO_Request>::value &&
    has_fixed_size<ros2_hi6_msgs::srv::GetIO_Response>::value
  >
{
};

template<>
struct has_bounded_size<ros2_hi6_msgs::srv::GetIO>
  : std::integral_constant<
    bool,
    has_bounded_size<ros2_hi6_msgs::srv::GetIO_Request>::value &&
    has_bounded_size<ros2_hi6_msgs::srv::GetIO_Response>::value
  >
{
};

template<>
struct is_service<ros2_hi6_msgs::srv::GetIO>
  : std::true_type
{
};

template<>
struct is_service_request<ros2_hi6_msgs::srv::GetIO_Request>
  : std::true_type
{
};

template<>
struct is_service_response<ros2_hi6_msgs::srv::GetIO_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // ROS2_HI6_MSGS__SRV__DETAIL__GET_IO__TRAITS_HPP_
