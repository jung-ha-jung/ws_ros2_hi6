

/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from GetIO_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef GetIO__215124834_h
#define GetIO__215124834_h

#ifndef NDDS_STANDALONE_TYPE
#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif
#else
#include "ndds_standalone_type.h"
#endif

namespace ros2_hi6_msgs {
    namespace srv {
        namespace dds_ {

            extern const char *GetIO_Request_TYPENAME;

            struct GetIO_Request_Seq;
            #ifndef NDDS_STANDALONE_TYPE
            class GetIO_Request_TypeSupport;
            class GetIO_Request_DataWriter;
            class GetIO_Request_DataReader;
            #endif

            class GetIO_Request_ 
            {
              public:
                typedef struct GetIO_Request_Seq Seq;
                #ifndef NDDS_STANDALONE_TYPE
                typedef GetIO_Request_TypeSupport TypeSupport;
                typedef GetIO_Request_DataWriter DataWriter;
                typedef GetIO_Request_DataReader DataReader;
                #endif

                DDS_Char *   type_ ;
                DDS_Long   blk_no_ ;
                DDS_Long   sig_no_ ;

            };
            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)
            #endif

            NDDSUSERDllExport DDS_TypeCode* GetIO_Request__get_typecode(void); /* Type code */

            DDS_SEQUENCE(GetIO_Request_Seq, GetIO_Request_);

            NDDSUSERDllExport
            RTIBool GetIO_Request__initialize(
                GetIO_Request_* self);

            NDDSUSERDllExport
            RTIBool GetIO_Request__initialize_ex(
                GetIO_Request_* self,RTIBool allocatePointers,RTIBool allocateMemory);

            NDDSUSERDllExport
            RTIBool GetIO_Request__initialize_w_params(
                GetIO_Request_* self,
                const struct DDS_TypeAllocationParams_t * allocParams);  

            NDDSUSERDllExport
            void GetIO_Request__finalize(
                GetIO_Request_* self);

            NDDSUSERDllExport
            void GetIO_Request__finalize_ex(
                GetIO_Request_* self,RTIBool deletePointers);

            NDDSUSERDllExport
            void GetIO_Request__finalize_w_params(
                GetIO_Request_* self,
                const struct DDS_TypeDeallocationParams_t * deallocParams);

            NDDSUSERDllExport
            void GetIO_Request__finalize_optional_members(
                GetIO_Request_* self, RTIBool deletePointers);  

            NDDSUSERDllExport
            RTIBool GetIO_Request__copy(
                GetIO_Request_* dst,
                const GetIO_Request_* src);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace srv  */
} /* namespace ros2_hi6_msgs  */
namespace ros2_hi6_msgs {
    namespace srv {
        namespace dds_ {

            extern const char *GetIO_Response_TYPENAME;

            struct GetIO_Response_Seq;
            #ifndef NDDS_STANDALONE_TYPE
            class GetIO_Response_TypeSupport;
            class GetIO_Response_DataWriter;
            class GetIO_Response_DataReader;
            #endif

            class GetIO_Response_ 
            {
              public:
                typedef struct GetIO_Response_Seq Seq;
                #ifndef NDDS_STANDALONE_TYPE
                typedef GetIO_Response_TypeSupport TypeSupport;
                typedef GetIO_Response_DataWriter DataWriter;
                typedef GetIO_Response_DataReader DataReader;
                #endif

                DDS_Long   val_ ;
                DDS_Boolean   success_ ;

            };
            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)
            #endif

            NDDSUSERDllExport DDS_TypeCode* GetIO_Response__get_typecode(void); /* Type code */

            DDS_SEQUENCE(GetIO_Response_Seq, GetIO_Response_);

            NDDSUSERDllExport
            RTIBool GetIO_Response__initialize(
                GetIO_Response_* self);

            NDDSUSERDllExport
            RTIBool GetIO_Response__initialize_ex(
                GetIO_Response_* self,RTIBool allocatePointers,RTIBool allocateMemory);

            NDDSUSERDllExport
            RTIBool GetIO_Response__initialize_w_params(
                GetIO_Response_* self,
                const struct DDS_TypeAllocationParams_t * allocParams);  

            NDDSUSERDllExport
            void GetIO_Response__finalize(
                GetIO_Response_* self);

            NDDSUSERDllExport
            void GetIO_Response__finalize_ex(
                GetIO_Response_* self,RTIBool deletePointers);

            NDDSUSERDllExport
            void GetIO_Response__finalize_w_params(
                GetIO_Response_* self,
                const struct DDS_TypeDeallocationParams_t * deallocParams);

            NDDSUSERDllExport
            void GetIO_Response__finalize_optional_members(
                GetIO_Response_* self, RTIBool deletePointers);  

            NDDSUSERDllExport
            RTIBool GetIO_Response__copy(
                GetIO_Response_* dst,
                const GetIO_Response_* src);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace srv  */
} /* namespace ros2_hi6_msgs  */

#endif /* GetIO_ */

