

/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from Status_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef Status__774584924_h
#define Status__774584924_h

#ifndef NDDS_STANDALONE_TYPE
#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif
#else
#include "ndds_standalone_type.h"
#endif

namespace ros2_hi6_msgs {
    namespace srv {
        namespace dds_ {

            extern const char *Status_Request_TYPENAME;

            struct Status_Request_Seq;
            #ifndef NDDS_STANDALONE_TYPE
            class Status_Request_TypeSupport;
            class Status_Request_DataWriter;
            class Status_Request_DataReader;
            #endif

            class Status_Request_ 
            {
              public:
                typedef struct Status_Request_Seq Seq;
                #ifndef NDDS_STANDALONE_TYPE
                typedef Status_Request_TypeSupport TypeSupport;
                typedef Status_Request_DataWriter DataWriter;
                typedef Status_Request_DataReader DataReader;
                #endif

                DDS_Long   data1_ ;
                DDS_Long   data2_ ;

            };
            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)
            #endif

            NDDSUSERDllExport DDS_TypeCode* Status_Request__get_typecode(void); /* Type code */

            DDS_SEQUENCE(Status_Request_Seq, Status_Request_);

            NDDSUSERDllExport
            RTIBool Status_Request__initialize(
                Status_Request_* self);

            NDDSUSERDllExport
            RTIBool Status_Request__initialize_ex(
                Status_Request_* self,RTIBool allocatePointers,RTIBool allocateMemory);

            NDDSUSERDllExport
            RTIBool Status_Request__initialize_w_params(
                Status_Request_* self,
                const struct DDS_TypeAllocationParams_t * allocParams);  

            NDDSUSERDllExport
            void Status_Request__finalize(
                Status_Request_* self);

            NDDSUSERDllExport
            void Status_Request__finalize_ex(
                Status_Request_* self,RTIBool deletePointers);

            NDDSUSERDllExport
            void Status_Request__finalize_w_params(
                Status_Request_* self,
                const struct DDS_TypeDeallocationParams_t * deallocParams);

            NDDSUSERDllExport
            void Status_Request__finalize_optional_members(
                Status_Request_* self, RTIBool deletePointers);  

            NDDSUSERDllExport
            RTIBool Status_Request__copy(
                Status_Request_* dst,
                const Status_Request_* src);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace srv  */
} /* namespace ros2_hi6_msgs  */
namespace ros2_hi6_msgs {
    namespace srv {
        namespace dds_ {

            extern const char *Status_Response_TYPENAME;

            struct Status_Response_Seq;
            #ifndef NDDS_STANDALONE_TYPE
            class Status_Response_TypeSupport;
            class Status_Response_DataWriter;
            class Status_Response_DataReader;
            #endif

            class Status_Response_ 
            {
              public:
                typedef struct Status_Response_Seq Seq;
                #ifndef NDDS_STANDALONE_TYPE
                typedef Status_Response_TypeSupport TypeSupport;
                typedef Status_Response_DataWriter DataWriter;
                typedef Status_Response_DataReader DataReader;
                #endif

                DDS_Long   result_ ;

            };
            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)
            #endif

            NDDSUSERDllExport DDS_TypeCode* Status_Response__get_typecode(void); /* Type code */

            DDS_SEQUENCE(Status_Response_Seq, Status_Response_);

            NDDSUSERDllExport
            RTIBool Status_Response__initialize(
                Status_Response_* self);

            NDDSUSERDllExport
            RTIBool Status_Response__initialize_ex(
                Status_Response_* self,RTIBool allocatePointers,RTIBool allocateMemory);

            NDDSUSERDllExport
            RTIBool Status_Response__initialize_w_params(
                Status_Response_* self,
                const struct DDS_TypeAllocationParams_t * allocParams);  

            NDDSUSERDllExport
            void Status_Response__finalize(
                Status_Response_* self);

            NDDSUSERDllExport
            void Status_Response__finalize_ex(
                Status_Response_* self,RTIBool deletePointers);

            NDDSUSERDllExport
            void Status_Response__finalize_w_params(
                Status_Response_* self,
                const struct DDS_TypeDeallocationParams_t * deallocParams);

            NDDSUSERDllExport
            void Status_Response__finalize_optional_members(
                Status_Response_* self, RTIBool deletePointers);  

            NDDSUSERDllExport
            RTIBool Status_Response__copy(
                Status_Response_* dst,
                const Status_Response_* src);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace srv  */
} /* namespace ros2_hi6_msgs  */

#endif /* Status_ */

