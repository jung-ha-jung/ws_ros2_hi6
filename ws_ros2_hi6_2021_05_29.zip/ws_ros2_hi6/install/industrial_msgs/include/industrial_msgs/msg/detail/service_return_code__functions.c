// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from industrial_msgs:msg/ServiceReturnCode.idl
// generated code does not contain a copyright notice
#include "industrial_msgs/msg/detail/service_return_code__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


bool
industrial_msgs__msg__ServiceReturnCode__init(industrial_msgs__msg__ServiceReturnCode * msg)
{
  if (!msg) {
    return false;
  }
  // val
  return true;
}

void
industrial_msgs__msg__ServiceReturnCode__fini(industrial_msgs__msg__ServiceReturnCode * msg)
{
  if (!msg) {
    return;
  }
  // val
}

industrial_msgs__msg__ServiceReturnCode *
industrial_msgs__msg__ServiceReturnCode__create()
{
  industrial_msgs__msg__ServiceReturnCode * msg = (industrial_msgs__msg__ServiceReturnCode *)malloc(sizeof(industrial_msgs__msg__ServiceReturnCode));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(industrial_msgs__msg__ServiceReturnCode));
  bool success = industrial_msgs__msg__ServiceReturnCode__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
industrial_msgs__msg__ServiceReturnCode__destroy(industrial_msgs__msg__ServiceReturnCode * msg)
{
  if (msg) {
    industrial_msgs__msg__ServiceReturnCode__fini(msg);
  }
  free(msg);
}


bool
industrial_msgs__msg__ServiceReturnCode__Sequence__init(industrial_msgs__msg__ServiceReturnCode__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  industrial_msgs__msg__ServiceReturnCode * data = NULL;
  if (size) {
    data = (industrial_msgs__msg__ServiceReturnCode *)calloc(size, sizeof(industrial_msgs__msg__ServiceReturnCode));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = industrial_msgs__msg__ServiceReturnCode__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        industrial_msgs__msg__ServiceReturnCode__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
industrial_msgs__msg__ServiceReturnCode__Sequence__fini(industrial_msgs__msg__ServiceReturnCode__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      industrial_msgs__msg__ServiceReturnCode__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

industrial_msgs__msg__ServiceReturnCode__Sequence *
industrial_msgs__msg__ServiceReturnCode__Sequence__create(size_t size)
{
  industrial_msgs__msg__ServiceReturnCode__Sequence * array = (industrial_msgs__msg__ServiceReturnCode__Sequence *)malloc(sizeof(industrial_msgs__msg__ServiceReturnCode__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = industrial_msgs__msg__ServiceReturnCode__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
industrial_msgs__msg__ServiceReturnCode__Sequence__destroy(industrial_msgs__msg__ServiceReturnCode__Sequence * array)
{
  if (array) {
    industrial_msgs__msg__ServiceReturnCode__Sequence__fini(array);
  }
  free(array);
}
