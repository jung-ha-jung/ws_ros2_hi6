import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import ThisLaunchFileDir
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
from launch.actions import ExecuteProcess
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    gazebo_dir = os.path.join(get_package_share_directory('gazebo_ros'),'launch')
    # world = os.path.join(get_package_share_directory('gis_gazebo'), 'worlds', 'test.world')

    urdf = os.path.join(
        get_package_share_directory('hyundai_description'),
        'urdf','hyundai_robot.urdf')

#    model_path = os.path.join(
#        get_package_share_directory('gis_gazebo'),
#        'models','pipe1.sdf')

    use_sim_time = LaunchConfiguration('use_sim_time', default=True) 

    return LaunchDescription([
        #退出gazebo时gzserver经常关不掉，所以打开gazebo前先关掉gzserver
        ExecuteProcess(
            cmd=['killall','-q', 'gzserver'],
            output='screen'),
        ExecuteProcess(
            cmd=['killall','-q', 'gzclient'],
            output='screen'),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([gazebo_dir, '/gzserver.launch.py']),
            # launch_arguments={
            #     'world': world
            #     }.items(),
        ),
        

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([gazebo_dir ,'/gzclient.launch.py'])),


        #使用-file 打开sdf文件 
        #使用-database需要先将模型路径添加到GAZEBO_MODEL_PATH  'export GAZEBO_MODEL_PATH=$GAZEBO_MODEL_PATH:model_path'  而且模型需要参照gazebo中的标准写法才能成功加载
        #使用-topic订阅机器人话题 话题由robot_state_publisher发布  其打开的是urdf文件
        Node(package='gazebo_ros', executable='spawn_entity.py',
                        arguments=[
                            '-x','0.0',
                            '-y','0.0',
                            '-z','2.0',
                            '-Y','0.0',  #yaw
                            '-entity', 'hyundai_robot',   #gazebo中机器命名
                            # '-database', 'cardboard_box',
                            # '-file',model_path,
                            '-topic','robot_description',
                            ],
                        output='screen'),

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'use_sim_time': use_sim_time},
                {'publish_frequency':100.0},
                ],
            arguments=[urdf]
            ),

    ])