import os
from glob import glob
from setuptools import setup
from setuptools import find_packages

package_name = 'ros2_hi6_test'

setup(
    name=package_name,
    version='1.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    author='hajung',
    author_email='hajung815@gmail.com',
    maintainer='hajung',
    maintainer_email='hajung815@gmail.com',
    description='Interface package test between ros2 and hi6',
    license='BSD',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'set_drive_power_test = ros2_hi6_test.set_drive_power_test:main',
            'start_motion_test = ros2_hi6_test.start_motion_test:main',
            'stop_motion_test = ros2_hi6_test.stop_motion_test:main',
            'service_set_io_test = ros2_hi6_test.service_set_io_test:main',
            'service_get_io_test = ros2_hi6_test.service_get_io_test:main',
            'service_status_test = ros2_hi6_test.service_status_test:main',
            'joystick_test = ros2_hi6_test.joystick_test:main',
            'joint_trajectory_test = ros2_hi6_test.joint_trajectory_test:main',
        ],
    },
)
