import sys
import rclpy
from rclpy.node import Node
from industrial_msgs.msg import ServiceReturnCode
from industrial_msgs.srv import SetDrivePower

class MinimalClientAsync(Node):

    def __init__(self):
        super().__init__('minimal_client_async')
        self.client_ = self.create_client(SetDrivePower, sys.argv[1])
        while not self.client_.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.request = SetDrivePower.Request()

    def send_request(self):
        if (sys.argv[2] == 'True'):
            self.request.drive_power = True
        elif (sys.argv[2] == 'False'):
            self.request.drive_power = False
        else:
            print('input parameter error')
            rclpy.shutdown()
            return
        self.get_logger().info('set_drive_power=%d' % (self.request.drive_power))
        self.future = self.client_.call_async(self.request)

def main(args=None):
    rclpy.init(args=args)
    minimal_client = MinimalClientAsync()
    minimal_client.send_request()

    while rclpy.ok():
        rclpy.spin_once(minimal_client)
        if minimal_client.future.done():
            try:
                response = minimal_client.future.result()
            except Exception as e:
                minimal_client.get_logger().info('Service call failed %r' % (e,))
        else:
            minimal_client.get_logger().info('Success')
        break

    minimal_client.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
