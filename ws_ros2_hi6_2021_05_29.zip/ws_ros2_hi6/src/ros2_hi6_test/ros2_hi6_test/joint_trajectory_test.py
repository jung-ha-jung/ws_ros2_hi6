import rclpy
from rclpy.node import Node
from rclpy.duration import Duration
from rclpy.time import Time
import math, time

from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

class JointTrajectoryTest(Node):

    def __init__(self):
        super().__init__('joint_trajectory_test')
        self.publisher_ = self.create_publisher(JointTrajectory, 'joint_trajectory', 10)
        timer_period = 3  # seconds
#        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.i = 0
        self.timer_callback() # once

    def timer_callback(self):
        msg = JointTrajectory()
#        msg.header.seq = self.i
        msg.header.stamp = self.get_clock().now().to_msg() # rclpy.Time.now() : ROS1
        msg.header.frame_id = 'joint'

        joint_no = 6
        for i in range(joint_no):
            msg.joint_names.append('hyundai_joint%d' % (1 + i))

        n = 1500
        dt = 0.01
        rps = 0.05

        for i in range(n):
            point = JointTrajectoryPoint()
            theta = rps*2.0*math.pi*i*dt
            x1 = -0.5*math.sin(2*theta)
            x2 =  0.5*math.sin(1*theta)

            point.positions.append(x1) # 1
            point.positions.append(1.57 + x2) # 2
            point.positions.append(x1) # 3
            point.positions.append(0.0) # 4
            point.positions.append(0.0) # 5
            point.positions.append(0.0) # 6

            point.velocities.append(0.0) # 1
            point.velocities.append(0.0) # 2
            point.velocities.append(0.0) # 3
            point.velocities.append(0.0) # 4
            point.velocities.append(0.0) # 5
            point.velocities.append(0.0) # 6

            point.accelerations.append(0.0) # 1
            point.accelerations.append(0.0) # 2
            point.accelerations.append(0.0) # 3
            point.accelerations.append(0.0) # 4
            point.accelerations.append(0.0) # 5
            point.accelerations.append(0.0) # 6

            msg.points.append(point)

            # set duration
            duration = Duration(seconds=dt)
            msg.points[i].time_from_start = duration.to_msg() # rospy.Duration.from_sec(dt) : ROS1
            self.get_logger().info('%d: positions[%f, %f, %f]' % (i, point.positions[0], point.positions[1], point.positions[2]))

#        print('positions=%f,%f' % (msg.points[0].positions[1], msg.points[1].positions[1]))
        # Publish message
        self.publisher_.publish(msg)
#        self.get_logger().info('Publishing: "%f"' % msg.points[0].positions[0])
        self.i += 1

def main(args=None):
    rclpy.init(args=args)

    joint_trajectory_test = JointTrajectoryTest()

    rclpy.spin(joint_trajectory_test)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    joint_trajectory_test.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
