import rclpy
from rclpy.node import Node
import sys, select, termios, tty

from sensor_msgs.msg import Joy

class JoystickTest(Node):

    def __init__(self):
        super().__init__('joystick_test')
        self.settings = termios.tcgetattr(sys.stdin)
        self.publisher_ = self.create_publisher(Joy, 'joy', 10)
        timer_period = 0.5  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.i = 0

    def timer_callback(self):
        msg = Joy()
        for i in range(10):
            msg.axes.append(0.0)
            msg.buttons.append(0)

        key = self.getKey()
        if key == '' :
            return

        if key == '!' :
            msg.axes[0] = -1.0
        elif key == '1' :
            msg.axes[0] = 1.0
        elif key == '@' :
            msg.axes[1] = -1.0
        elif key == '2' :
            msg.axes[1] = 1.0
        elif key == '#' :
            msg.axes[2] = -1.0
        elif key == '3' :
            msg.axes[2] = 1.0
        elif key == '$' :
            msg.axes[3] = -1.0
        elif key == '4' :
            msg.axes[3] = 1.0
        elif key == '%' :
            msg.axes[4] = -1.0
        elif key == '5' :
            msg.axes[4] = 1.0
        elif key == '^' :
            msg.axes[5] = -1.0
        elif key == '6' :
            msg.axes[5] = 1.0
        elif key == '&' :
            msg.axes[6] = -1.0
        elif key == '7' :
            msg.axes[6] = 1.0
        elif key == '*' :
            msg.axes[7] = -1.0
        elif key == '8' :
            msg.axes[7] = 1.0

        print('key=%s,%f' % (key, msg.axes[0]))
        # Publish message
        self.publisher_.publish(msg)
#        self.get_logger().info('Publishing: "%f"' % self.msg.axes[0])
        self.i += 1

    def getKey(self):
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
        if rlist:
            key = sys.stdin.read(1)
        else:
            key = ''

        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key


def main(args=None):
    rclpy.init(args=args)

    joystick_test = JoystickTest()

    rclpy.spin(joystick_test)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    joystick_test.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
