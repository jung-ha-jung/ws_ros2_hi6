import sys
import rclpy
from rclpy.node import Node
from industrial_msgs.msg import ServiceReturnCode
from industrial_msgs.srv import StopMotion

class ServiceClientAsync(Node):

    def __init__(self):
        super().__init__('service_client_async')
        self.client_ = self.create_client(StopMotion, sys.argv[1])
        while not self.client_.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.request = StopMotion.Request()

    def send_request(self):
        self.get_logger().info('command : %s' %sys.argv[1])
        self.future = self.client_.call_async(self.request)

def main(args=None):
    rclpy.init(args=args)
    service_client = ServiceClientAsync()
    service_client.send_request()

    while rclpy.ok():
        rclpy.spin_once(service_client)
        if service_client.future.done():
            try:
                response = service_client.future.result()
            except Exception as e:
                service_client.get_logger().info('Service call failed %r' % (e,))
        else:
            service_client.get_logger().info('Success')
        break

    service_client.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
