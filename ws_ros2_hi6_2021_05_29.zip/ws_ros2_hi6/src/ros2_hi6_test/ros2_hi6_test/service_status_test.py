import sys
import rclpy
from rclpy.node import Node
from ros2_hi6_msgs.srv import Status

class MinimalClientAsync(Node):

    def __init__(self):
        super().__init__('minimal_client_async')
        self.client_ = self.create_client(Status, sys.argv[1])
        while not self.client_.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.request = Status.Request()

    def send_request(self):
        self.request.data1 = int(sys.argv[2])
        self.request.data2 = int(sys.argv[3])
        self.get_logger().info('command : %s, data1=%d, data2=%d' % (sys.argv[1], self.request.data1, self.request.data2))
        self.future = self.client_.call_async(self.request)

def main(args=None):
    rclpy.init(args=args)
    minimal_client = MinimalClientAsync()
    minimal_client.send_request()

    while rclpy.ok():
        rclpy.spin_once(minimal_client)
        if minimal_client.future.done():
            try:
                response = minimal_client.future.result()
            except Exception as e:
                minimal_client.get_logger().info('Service call failed %r' % (e,))
        else:
            minimal_client.get_logger().info('Success')
        break

    minimal_client.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
