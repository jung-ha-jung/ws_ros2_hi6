import rclpy
from rclpy.node import Node
import requests
import json
import web_service
import math

from sensor_msgs.msg import Joy

url_joy = '/project/robot/joystick/joy'

class Joystick(Node):

    def __init__(self):
        super().__init__('joystick')
        self.http = web_service.http_client()
        self.subscription = self.create_subscription(Joy, 'joy', self.listener_joy, 10)
        self.subscription  # prevent unused variable warning

    def listener_joy(self, msg):

        print('axes=%f, %f, %f, %f, %f, %f' % (msg.axes[0], msg.axes[1], msg.axes[2], msg.axes[3], msg.axes[4], msg.axes[5]))
        data = dict()
        data['axes'] = msg.axes.tolist() # 축
        data['buttons'] = msg.buttons.tolist() # 버튼
        json_data = json.dumps(data)
        response = self.http.service_request('POST', url_joy, json_data, "")
        if (response == False):
            return


def main(args=None):
    rclpy.init(args=args)
    joystick = Joystick()

    rclpy.spin(joystick)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    joystick.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
