import rclpy
from rclpy.node import Node
import requests
import json
import web_service
import math
import time
from rclpy.duration import Duration
from rclpy.time import Time

from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

url_joint_trajectory = '/project/robot/trajectory/joint_trajectory'

class JointTrajectoryHi6(Node):

    def __init__(self):
        super().__init__('joint_trajectory')
        self.http = web_service.http_client()
        self.subscription = self.create_subscription(JointTrajectory, 'joint_trajectory', self.listener_joint_trajectory, 10)
        self.subscription  # prevent unused variable warning

    def listener_joint_trajectory(self, msg):

        data = dict()
        # header
#        data['seq'] = msg.header.seq
#        data['sec'] = msg.header.stamp.sec
#        data['nsec'] = msg.header.stamp.nanosec
#        data['frame_id'] = msg.header.frame_id

        # joint names
        n_joint = len(msg.joint_names)
        data['joint_names'] = msg.joint_names

        # points
        n_point = len(msg.points)
        print('n_joint=%d, n_point=%d' % (n_joint, n_point))
        points = dict()
        for i in range(n_point):
            point = dict()
            point['positions'] = msg.points[i].positions.tolist()
            point['velocities'] = msg.points[i].velocities.tolist()
            point['accelerations'] = msg.points[i].accelerations.tolist()
#            point['effort'] = msg.points[i].effort.tolist()
            point['time_from_start'] = self.seconds(msg.points[i].time_from_start)
            points['point_%d' % (1 + i)] = point

        data['points'] = points
        json_data = json.dumps(data)
#        print(data)
        response = self.http.service_request('POST', url_joint_trajectory, json_data, "", 20)
        if (response == False):
           return

    def seconds(self, duration):
        return (duration.sec + (duration.nanosec / 1e9))

def main(args=None):
    rclpy.init(args=args)

    joint_trajectory = JointTrajectoryHi6()

    rclpy.spin(joint_trajectory)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    joint_trajectory.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
