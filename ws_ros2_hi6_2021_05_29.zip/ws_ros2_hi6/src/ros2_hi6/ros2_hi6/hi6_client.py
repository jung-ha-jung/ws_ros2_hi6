from math import *
import rclpy
import requests
import json
import time
import sys
import web_service

from rclpy.node import Node
from industrial_msgs.msg import ServiceReturnCode
from industrial_msgs.srv import SetDrivePower
from industrial_msgs.srv import StartMotion
from industrial_msgs.srv import StopMotion
from ros2_hi6_msgs.srv import Trigger
from ros2_hi6_msgs.srv import SetIO
from ros2_hi6_msgs.srv import GetIO
from ros2_hi6_msgs.srv import Status

url_motor_on = '/project/robot/motor_on'
url_motor_off = '/project/robot/motor_off'
url_start = '/project/robot/start'
url_stop = '/project/robot/stop'
url_di_val = '/project/control/ios/dio/di_val'
url_do_val = '/project/control/ios/dio/do_val'
url_si_val = '/project/control/ios/sio/si_val'
url_so_val = '/project/control/ios/sio/so_val'
url_service = '/project/service'
url_status2 = url_service + '/svc_status2'


class Hi6Client(Node):

    def __init__(self):
        super().__init__('hi6_client')
        self.http = web_service.http_client()
        self.data = dict()       
        self.server_ = []
        self.server_.append(self.create_service(SetDrivePower, 'set_drive_power', self.set_drive_power))
        self.server_.append(self.create_service(StartMotion, 'start_motion', self.start_motion))
        self.server_.append(self.create_service(StopMotion, 'stop_motion', self.stop_motion))
        self.server_.append(self.create_service(SetIO, 'set_do', self.set_do))
        self.server_.append(self.create_service(SetIO, 'set_so', self.set_so))
        self.server_.append(self.create_service(GetIO, 'get_do', self.get_do))
        self.server_.append(self.create_service(GetIO, 'get_so', self.get_so))
        self.server_.append(self.create_service(GetIO, 'get_di', self.get_di))
        self.server_.append(self.create_service(GetIO, 'get_si', self.get_si))
        self.server_.append(self.create_service(Status, 'total_axis_no', self.total_axis_no))

    def set_drive_power(self, request_msg, response_msg):
        command = 'set_drive_power'
        if (request_msg.drive_power == True):
            url_motor_power = url_motor_on
        else:
            url_motor_power = url_motor_off
        response = self.http.service_request('POST', url_motor_power, '', command)
        response_msg = self.make_response_service_return_code(command, response, response_msg) #결과값으로 응답메시지 생성
        return response_msg

    def start_motion(self, request_msg, response_msg):
        command = 'start_motion'
        response = self.http.service_request('POST', url_start, '', command)
        response_msg = self.make_response_service_return_code(command, response, response_msg) # 결과값으로 응답메시지 생성
        return response_msg

    def stop_motion(self, request_msg, response_msg):
        command = 'stop_motion'
        response = self.http.service_request('POST', url_stop, '', command)
        response_msg = self.make_response_service_return_code(command, response, response_msg) # 결과값으로 응답메시지 생성
        return response_msg

    def set_do(self, request_msg, response_msg):
        command = 'set_do'
        data = dict()
        data['type'] = request_msg.type
        data['blk_no'] = request_msg.blk_no
        data['sig_no'] = request_msg.sig_no
        data['val'] = request_msg.val
        json_data = json.dumps(data)
        response = self.http.service_request('POST', url_do_val, json_data, command)
        response_msg = self.make_response_set_io(command, response, response_msg) # 결과값으로 응답메시지 생성
        return response_msg

    def set_so(self, request_msg, response_msg):
        command = 'set_so'
        data = dict()
        data['type'] = request_msg.type
        data['sig_no'] = request_msg.sig_no
        data['val'] = request_msg.val
        json_data = json.dumps(data)
        response = self.http.service_request('POST', url_so_val, json_data, command)
        response_msg = self.make_response_set_io(command, response, response_msg) # 결과값으로 응답메시지 생성
        return response_msg

    def get_do(self, request_msg, response_msg):
        command = 'get_do'
        args = ('?type=%s&blk_no=%d&sig_no=%d' % (request_msg.type, request_msg.blk_no, request_msg.sig_no))
        url_get_svc = url_do_val + args
        print(url_get_svc)
        response = self.http.service_request('GET', url_get_svc, "", command)
        response_msg = self.make_response_get_io(command, response, response_msg) # 결과값으로 응답메시지 생성
        return response_msg

    def get_so(self, request_msg, response_msg):
        command = 'get_so'
        args = ('?type=%s&sig_no=%d' % (request_msg.type, request_msg.sig_no))
        url_get_svc = url_so_val + args
        response = self.http.service_request('GET', url_get_svc, "", command)
        response_msg = self.make_response_get_io(command, response, response_msg) # 결과값으로 응답메시지 생성
        return response_msg

    def get_di(self, request_msg, response_msg):
        command = 'get_di'
        args = ('?type=%s&blk_no=%d&sig_no=%d' % (request_msg.type, request_msg.blk_no, request_msg.sig_no))
        url_get_svc = url_di_val + args        
        response = self.http.service_request('GET', url_get_svc, "", command)
        response_msg = self.make_response_get_io(command, response, response_msg) # 결과값으로 응답메시지 생성
        return response_msg

    def get_si(self, request_msg, response_msg):
        command = 'get_si'
        args = ('?type=%s&sig_no=%d' % (request_msg.type, request_msg.sig_no))
        url_get_svc = url_si_val + args
        response = self.http.service_request('GET', url_get_svc, "", command)
        response_msg = self.make_response_get_io(command, response, response_msg) # 결과값으로 응답메시지 생성
        return response_msg

    def total_axis_no(self, request_msg, response_msg):
        response_msg = self.get_status2('/total_axis_no', request_msg, response_msg) # 서비스 호출
        return response_msg


    # 결과값으로 응답메시지 생성
    def make_response_service_return_code(self, command, response, response_msg):
        if (response == None):
            response_msg.code.val = ServiceReturnCode.FAILURE
        else:
            response_msg.code.val = ServiceReturnCode.SUCCESS
        self.get_logger().info('%s : success=%d' % (command, response_msg.code.val))
        return response_msg

    # 결과값으로 응답메시지 생성
    def make_response_trigger(self, command, response, response_msg):
        if (response == None):
            response_msg.success = False
        else:
            response_msg.success = response
        self.get_logger().info('%s : success=%d' % (command, response_msg.success))
        return response_msg

    # 결과값으로 응답메시지 생성
    def make_response_set_io(self, command, response, response_msg):
        if (response == None):
            response_msg.success = False
        else:
            response_msg.success = response
        self.get_logger().info('%s : success=%d' % (command, response_msg.success))
        return response_msg

    # 결과값으로 응답메시지 생성
    def make_response_get_io(self, command, response, response_msg):
        if (response == None):
            response_msg.success = False
        else:
            response_msg.success = response['ok']
            response_msg.val = int(response['val'])
        self.get_logger().info('%s : success=%d, val=%d' % (command, response_msg.success, response_msg.val))
        return response_msg

    # 결과값으로 응답메시지 생성
    def get_status2(self, url_sub, request_msg, response_msg):
        url_sub =  url_sub + ('?dt1=%s&dt2=%s' % (request_msg.data1, request_msg.data2))
        response = self.http.service_request('GET', url_status2 + url_sub, '', "")
        response_msg.result = self.make_response_status(url_sub, response) # 결과값으로 응답메시지 생성
        return response_msg

    # get_status2 수행 결과값으로 응답메시지 생성
    def make_response_status(self, url_sub, response):
        if (response != None and 'text' in response):
            result = int(response['text'])

        else:
            result = 0
        self.get_logger().info('%s : result=%d' % (url_sub, result))
        return result


def main(args=None):
    rclpy.init(args=args)
    hi6_client = Hi6Client()
    rclpy.spin(hi6_client)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
